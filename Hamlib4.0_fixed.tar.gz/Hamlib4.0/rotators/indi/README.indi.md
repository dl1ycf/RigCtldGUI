INDI rotator backend
====================

This backend lets Hamlib control an astronomical (telescope) rotator through an
[INDI](https://indilib.org/) server.

The easiest way to set up an INDI server is to use [EKOS](https://www.indilib.org/about/ekos.html),
which is available in [KStars](https://edu.kde.org/kstars/).
